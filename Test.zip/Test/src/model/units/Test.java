package model.units;

public class Test {

	public Test() {
		// TODO Auto-generated constructor stub
	}

}
