package model.people;

public class Test {

	public Test() {
		// TODO Auto-generated constructor stub
	}

}
