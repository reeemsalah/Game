package model.disasters;

import model.infrastructure.ResidentialBuilding;

public class Fire extends Disaster{

	public Fire(int cycle,ResidentialBuilding target) {
		// TODO Auto-generated constructor stub
		super(cycle,target);
	}

}
