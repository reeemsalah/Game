package model.disasters;

public class GasLeak extends Disaster{

	public GasLeak(int cycle, ResidentialBuilding target) {
		// TODO Auto-generated constructor stub
		super(cycle,target);
	}

}
