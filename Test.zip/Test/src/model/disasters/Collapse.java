package model.disasters;

import model.infrastructure.ResidentialBuilding;

public class Collapse extends Disaster {

	public Collapse(int cycle , ResidentialBuilding target) {
		// TODO Auto-generated constructor stub
		super(cycle,target);
		
	}

}
