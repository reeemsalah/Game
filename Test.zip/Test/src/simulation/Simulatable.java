package simulation;

public interface Simulatable {

}
