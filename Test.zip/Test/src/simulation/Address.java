package simulation;

public class Address {
	private int x;
	private int y;
	

	public Address(int x, int y) {
		// TODO Auto-generated constructor stub
		this.x=x;
		this.y=y;
	}


	public int getX() {
		return x;
	}


	public int getY() {
		return y;
	}

}
