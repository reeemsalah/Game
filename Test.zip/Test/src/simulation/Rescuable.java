package simulation;

public interface Rescuable {

}
