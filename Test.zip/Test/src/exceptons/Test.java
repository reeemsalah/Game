package exceptons;

public class Test {

	public Test() {
		// TODO Auto-generated constructor stub
	}

}
